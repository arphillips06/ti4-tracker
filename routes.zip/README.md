# Twilight Imperium Stats Tracker

A local self-hosted web application to track and analyse scores, objectives, and game stats for Twilight Imperium 4. This project is built using Go and is designed to help players keep a detailed record of their games and stats over time.
