import { useEffect, useState } from "react";

export default function useGameData(gameId) {
  const [game, setGame] = useState(null);
  const [objectives, setObjectives] = useState([]);
  const [objectiveScores, setObjectiveScores] = useState({});
  const [secretObjectives, setSecretObjectives] = useState([]);
  const [secretCounts, setSecretCounts] = useState({});
  const [mutinyUsed, setMutinyUsed] = useState(false);
  const [censureHolder, setCensureHolder] = useState(null);

  const fetchGame = async () => {
    const res = await fetch(`http://localhost:8080/games/${gameId}`);
    const data = await res.json();
    console.log("[fetchGame] Raw game data:", data);
    return data?.game || data; // Support both wrapped and direct response
  };

  const fetchObjectives = async () => {
    const res = await fetch(`http://localhost:8080/games/${gameId}/objectives`);
    return res.json();
  };

  const fetchScores = async () => {
    const res = await fetch(`http://localhost:8080/games/${gameId}/objectives/scores`);
    return res.json();
  };

  const fetchSecrets = async () => {
    const res = await fetch("http://localhost:8080/objectives/secrets/all");
    return res.json();
  };

  const refreshGameState = async () => {
    const [gameData, objectivesData, scoresData] = await Promise.all([
      fetchGame(),
      fetchObjectives(),
      fetchScores(),
    ]);

    console.log("[useGameData] Setting game state:", gameData);
    setGame(gameData);

    const map = {};
    (Array.isArray(scoresData) ? scoresData : scoresData?.value || []).forEach((entry) => {
      map[entry.objective_id] = entry.scored_by || [];
    });
    setObjectiveScores(map);

    setObjectives(Array.isArray(objectivesData) ? objectivesData : objectivesData?.value || []);
  };

  useEffect(() => {
    (async () => {
      console.log("[useEffect] Running initial game load for gameId:", gameId);
      const [gameData, secretData, scoresData, objectiveData] = await Promise.all([
        fetchGame(),
        fetchSecrets(),
        fetchScores(),
        fetchObjectives(),
      ]);

      console.log("[useEffect] All data fetched:");
      console.log("  Game:", gameData);
      console.log("  Secrets:", secretData.length);
      console.log("  Scores:", scoresData);
      console.log("  Objectives:", objectiveData);

      setGame(gameData);
      console.log("  → use_objective_decks =", gameData?.use_objective_decks);

      setMutinyUsed(gameData.AllScores?.some((s) => s.AgendaTitle === "Mutiny"));

      const initialSecrets = {};
      (gameData.players || []).forEach((p) => {
        initialSecrets[p.PlayerID || p.id] = 0;
      });
      setSecretCounts(initialSecrets);

      const scoreMap = {};
      (Array.isArray(scoresData) ? scoresData : scoresData?.value || []).forEach((entry) => {
        scoreMap[entry.objective_id] = entry.scored_by || [];
      });
      setObjectiveScores(scoreMap);

      const normalizedObjectives = Array.isArray(objectiveData)
        ? objectiveData
        : objectiveData?.value || [];
      setObjectives(normalizedObjectives);

      const normalizedSecrets = secretData.map((obj) => ({
        id: obj.ID,
        name: obj.name,
        phase: obj.phase?.toLowerCase() || obj.Phase?.toLowerCase() || "",
        ...obj,
      }));
      setSecretObjectives(normalizedSecrets);

      console.log("[useEffect] Finished setting state.");
    })();

    const match = game?.AllScores?.find(
      (s) => s.Type === "Agenda" && s.AgendaTitle === "Political Censure"
    );
    setCensureHolder(match?.PlayerID || null);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameId]);

  return {
    game,
    objectives,
    secretObjectives,
    secretCounts,
    setSecretCounts,
    objectiveScores,
    mutinyUsed,
    setGame,
    setObjectiveScores,
    refreshGameState,
    censureHolder,
  };
}
